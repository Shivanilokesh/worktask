 class Minimum  {
    public static void main(String[] args) {
        int[] numbers = {80, 40, 30, 50};
        
        // Initialize min and max with the first element of the array
        int min = numbers[0];
        int max = numbers[0];
        
        // Loop through the array to find min and max using ternary operators
        for (int i = 1; i < numbers.length; i++) {
            min = (numbers[i] < min) ? numbers[i] : min;
            max = (numbers[i] > max) ? numbers[i] : max;
        }
        
        // Print the result
        System.out.println("Minimum number: " + min);
        System.out.println("Maximum number: " + max);
    }
}
