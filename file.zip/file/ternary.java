class ternay {
  public static void main(String[] args) {
    
    // create a variable 
    int number = 24;

    String result = (number > 0) ? "Positive Number" : "Negative Number";
    System.out.println(result);
  }
  //create a variable
  int number = 50;

  String result = (number < 50) ? "positive number" : "negative number";
}