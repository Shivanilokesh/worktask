class multiplication {
    public static void main(String[] args) {
        int num1 = 20, num2 = 20, mul = 0;

        System.out.println("num1 ="+ num1);
        System.out.println("num2 ="+ num2);

        mul = num1 * num2;
        System.out.println("multiplication =" + mul);
    
}
}
