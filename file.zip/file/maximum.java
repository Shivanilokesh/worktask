class Maximum  {
    public static void main(String[] args) {
        int[] numbers = {80, 40, 30, 50};
        
        // Initialize  max with the first element of the array
        int max = numbers[0];
        
        // Loop through the array to find max using ternary operators
        for (int i = 1; i < numbers.length; i++) {
            max = (numbers[i] > max) ? numbers[i] : max;
        }
        
        // Print the result
        
        System.out.println("Maximum number: " + max);
    }
}