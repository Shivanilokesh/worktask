class addition{
    public static void main(String[] args) {
        int num1 = 10, num2 = 20, sum = 0;

        System.out.println("num1 ="+ num1);
        System.out.println("num2 ="+ num2);

        sum = num1 + num2;
        System.out.println("The sum =" + sum);
    }
}