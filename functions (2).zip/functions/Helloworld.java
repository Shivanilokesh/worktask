public class Helloworld {

    // function with no parameters and no return value
    public void printMessage() {
        System.out.println("Namaste");
    }

    public static void main(String[] args) {
        
        Helloworld helloWorld = new Helloworld();
        
        // Call the printMessage function
        helloWorld.printMessage();
    }
}
 
    

